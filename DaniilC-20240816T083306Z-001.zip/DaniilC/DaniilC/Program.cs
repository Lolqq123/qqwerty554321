﻿using System;

namespace DaniilC
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            //string strS = " ░▒▓███████▓▒░\n░▒▓█▓▒░ \n░▒▓█▓▒░ \n ░▒▓██████▓▒░\n       ░▒▓█▓▒░\n       ░▒▓█▓▒░\n░▒▓███████▓▒░";
            //Console.WriteLine(strS);
            //Console.WriteLine();
            //string strT = "+-+-+\n  |  \n  |  \n  |  \n  +  ";
            //Console.WriteLine(strT);
            //Console.WriteLine();
            //string strE = "+---+\n|    \n+---+\n|    \n+---+";
            //Console.WriteLine(strE);
            //Console.WriteLine();
            //string strM = "+   +\n|+ +|\n| + |\n|   |\n+   +";
            //Console.WriteLine(strM);
            //Console.WriteLine();
            //string str_ = "==========";
            //Console.WriteLine(str_);
            //Console.WriteLine();
            //string strDaniil = "+-+     +   +   + + + +    \n|   +  + +  |+  |     |   \n|   + +---+ | + | + + |    \n|   + |   | |  +| | | |    \n+-+   +   + +   + + + +---+";
            //Console.WriteLine(strDaniil);
            //Console.WriteLine();
            //Console.WriteLine(str_);
            //Console.WriteLine();
            //string strCsharp = "+---+  | | \n|     -+-+-\n|      | | \n|     -+-+-\n+---+  | | ";
            //Console.WriteLine(strCsharp);
            //Console.WriteLine();
            //string strSharp = " | | \n-+-+-\n | | \n-+-+-\n | | ";
            //Console.WriteLine(strSharp);
            //Console.WriteLine();
            //string strC = "+---+\n|    \n|    \n|    \n+---+";
            //Console.WriteLine(strC);
            //Console.WriteLine();
            //Console.WriteLine(str_);
            //Console.WriteLine();
            //Console.WriteLine(strS);
            //Console.WriteLine();
            //string strA = "  +  \n + + \n+---+\n|   |\n+   +";
            //Console.WriteLine(strA);
            //Console.WriteLine();
            //string strF = "+---+\n|    \n+-+\n|    \n+    ";
            //Console.WriteLine(strF);
            //Console.WriteLine();
            //Console.WriteLine(strE);
            //Console.WriteLine();
            //Console.WriteLine(strT);
            //Console.WriteLine();
            //string strY = "+   +\n|   |\n+---+\n    |\n+---+";
            //Console.WriteLine(strY);
            //Console.WriteLine();
            //Console.WriteLine(str_);
            //Console.WriteLine();
            //string strTriangle = "   *   \n  * *  \n *   * \n*******";
            //Console.WriteLine(strTriangle);
            //Console.WriteLine();
            //Console.WriteLine(str_);
            //Console.WriteLine();
            //string strHouse = "   *   \n  * *  \n *   * \n*******\n |   | \n |   | \n +---+ ";
            //Console.WriteLine(strHouse);
            //Console.WriteLine();
            //Console.WriteLine(str_);
            //Console.WriteLine();
            //string strLLV = " **  ** \n*  **  *\n*      *\n  *  *  \n   **   ";
            //Console.WriteLine(strLLV);
            //Console.WriteLine();
            //Console.WriteLine(str_);
            //Console.WriteLine();
            //string strPic = "  ##  \n  ||  \n  **  \n  **  \n  **  \n *  * \n*    *\n******\n******\n*    *\n*    *\n*    *\n **** ";
            //Console.WriteLine(strPic);
            //Console.WriteLine();
            //Console.WriteLine(str_);
            //Console.WriteLine();
            //string strI = "  +  \n     \n  +  \n  |  \n  +  ";
            //Console.WriteLine(strI);
            //Console.WriteLine();
            //string strO = " +-+ \n+   +\n|   |\n+   +\n +-+ ";
            //Console.WriteLine(strO);
            //Console.WriteLine();
            //string strL = "+    \n|    \n|    \n|    \n+---+";
            //Console.WriteLine(strL);
            //Console.WriteLine();
            //string strQ = " +-+ \n+   +\n| * |\n+  *+\n +-+*";
            //Console.WriteLine(strQ);
            //Console.WriteLine();
            //string strN = "+   +\n|+  |\n| + |\n|  +|\n+   +";
            //Console.WriteLine(strN);
            //Console.WriteLine();
            //Console.WriteLine(str_);
            //Console.WriteLine();
            //Console.WriteLine(strC);
            //Console.WriteLine();
            //Console.WriteLine(strO);
            //Console.WriteLine();
            //Console.WriteLine(strN);
            //Console.WriteLine();
            //Console.WriteLine(strS);
            //Console.WriteLine();
            //Console.WriteLine(strO);
            //Console.WriteLine();
            //Console.WriteLine(strL);
            //Console.WriteLine();
            //Console.WriteLine(strE);
            Console.WriteLine(" ░▒▓██████▓▒░ ░▒▓██████▓▒░░▒▓███████▓▒░ ░▒▓███████▓▒░░▒▓██████▓▒░░▒▓█▓▒░      ░▒▓████████▓▒░ \n░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░ \n░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░        \n░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░░▒▓██████▓▒░░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓██████▓▒░   \n░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░      ░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░ \n░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░      ░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░ \n ░▒▓██████▓▒░ ░▒▓██████▓▒░░▒▓█▓▒░░▒▓█▓▒░▒▓███████▓▒░ ░▒▓██████▓▒░░▒▓████████▓▒░▒▓████████▓▒░ ");
            //Console.WriteLine();
            //Console.WriteLine("Таблица умножения до 15");
            //for (int i = 1; i < 16; ++i)
            //{
            //for (int j = 1; j < 16; j++)
            //{
            //    Console.Write($"{i * j,-3} ");
            //}
            //Console.WriteLine();
            //Console.WriteLine();
            //}
            //int value = 0;
            //int num = 0;
            //string input_string = "";
            //int i = 0;
            //bool run = true;

            //Console.WriteLine("<<< Guess my number >>>");
            //Console.WriteLine("I choose number - you guess!");

            //while (run)
            //{

            //    Random rnd = new Random();
            //    value = rnd.Next(0, 20);
            //    Console.WriteLine("I choose number from 0 to 20, Your turn!");
            //    Console.WriteLine("Print number: ");
            //    for (i = 0; i < 10 && num != value; i++)
            //    {
            //        Console.WriteLine("Turn #" + i);
            //        input_string = Console.ReadLine();
            //        num = Int32.Parse(input_string);
            //        if (value != num)
            //        {
            //            Console.WriteLine("You Wrong!");
            //            if (num > value)
            //            {
            //                Console.WriteLine("Less");
            //            }
            //            else
            //            {
            //                Console.WriteLine("More");
            //            }
            //        }
            //    }
            //    if (num == value)
            //    {
            //        Console.WriteLine("You Win");
            //    }
            //    else
            //    {
            //        Console.WriteLine("Lose");
            //    }
            //    Console.WriteLine("Do you want to continue? Write yes/no");
            //    while (input_string != "yes" & input_string != "no")
            //    {
            //        input_string = Console.ReadLine();
            //        if (input_string == "yes")
            //        { }
            //        else
            //        {
            //            if (input_string == "no")
            //            {
            //                run = false;
            //            }
            //            else
            //            {
            //                Console.WriteLine("I don’t understand, please enter your answer");
            //            }
            //        }
            //    }
            //}
            //string name = "Daniil";
            //int age = 11;
            //bool isEmployed = false;
            //double weight = 32.43;
            //string games = "Yes";
            //string school = "Gymnasium 35";
            //int pcnum = 12;
            //double pizzacup4 = 0.25;

            //Console.WriteLine($"Name: {name}");
            //Console.WriteLine($"Age: {age}");
            //Console.WriteLine($"Weight: {weight}");
            //Console.WriteLine($"Is employed: {isEmployed}");
            //Console.WriteLine($"Play PC games: {games}");
            //Console.WriteLine($"Full name of the school: {school}");
            //Console.WriteLine($"Number of computers in the classroom: {pcnum}");
            //Console.WriteLine($"how much of the pizza will everyone get if it is divided among 4 people: {pizzacup4}");
            Console.Write("Enter your name: ");
            string name = Console.ReadLine();

            Console.Write("Enter age: ");
            int age = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter height: ");
            double height = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter your salary: ");
            decimal salary = Convert.ToDecimal(Console.ReadLine());

            Console.Write("Enter floors in school: ");
            int sfloors = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter your surname: ");
            string surname = Console.ReadLine();

            Console.Write("What part of the cake will everyone get if it is divided among 5 people: ");
            double cakescam = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter Phone number: ");
            double tnumber = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine($"Name: {name}   Age: {age}   Height: {height}   Salary: {salary}$   Floors in school: {sfloors}   Surname: {surname}   Mystery: {cakescam}   Phone number: {tnumber: + ### ## ###-##-##}");
        }
    }
}
